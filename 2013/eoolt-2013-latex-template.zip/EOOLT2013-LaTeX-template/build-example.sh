#!/bin/sh

latex eoolt-2013-latex-template
bibtex eoolt-2013-latex-template
latex eoolt-2013-latex-template
latex eoolt-2013-latex-template
dvips -t a4 -o eoolt-2013-latex-template.ps eoolt-2013-latex-template.dvi
ps2pdf eoolt-2013-latex-template.ps
